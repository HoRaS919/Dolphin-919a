package com.okh.business.replacement.ipc;

interface ITripServiceAidlInterface {
    void setVoiceAssistantEnabled(boolean enabled);
    boolean isVoiceAssistantEnabled();
    void dismissOverlay();
    String getLatestMetricsSummary();
}
