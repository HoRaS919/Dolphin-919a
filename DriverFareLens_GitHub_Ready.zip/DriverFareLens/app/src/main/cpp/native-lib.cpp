#include <jni.h>
#include <string>
#include <vector>
#include <cctype>
#include <cstdlib>

extern "C" JNIEXPORT jdoubleArray JNICALL
Java_com_okh_business_replacement_core_parser_NativeOfferParser_parseNativeTokens(
        JNIEnv* env,
        jobject /* this */,
        jstring rawTextStr) {

    if (rawTextStr == nullptr) {
        return nullptr;
    }

    const char* nativeStr = env->GetStringUTFChars(rawTextStr, nullptr);
    std::string text(nativeStr);
    env->ReleaseStringUTFChars(rawTextStr, nativeStr);

    double fare = 0.0;
    double distance = 0.0;
    double duration = 0.0;
    double rating = 4.85;

    // Fast zero-allocation token scanning in C++
    size_t len = text.length();
    for (size_t i = 0; i < len; ++i) {
        // Fast Fare Search (EGP, LE)
        if (i + 2 < len && (text[i] == 'L' || text[i] == 'l') && (text[i+1] == 'E' || text[i+1] == 'e')) {
            // Check preceding number
            int p = static_cast<int>(i) - 1;
            while (p >= 0 && std::isspace(static_cast<unsigned char>(text[p]))) p--;
            if (p >= 0 && std::isdigit(static_cast<unsigned char>(text[p]))) {
                int end = p + 1;
                while (p >= 0 && (std::isdigit(static_cast<unsigned char>(text[p])) || text[p] == '.' || text[p] == ',')) p--;
                fare = std::atof(text.substr(p + 1, end - p - 1).c_str());
            }
        }
        // Fast Distance Search (km)
        if (i + 1 < len && (text[i] == 'k' || text[i] == 'K') && (text[i+1] == 'm' || text[i+1] == 'M')) {
            int p = static_cast<int>(i) - 1;
            while (p >= 0 && std::isspace(static_cast<unsigned char>(text[p]))) p--;
            if (p >= 0 && std::isdigit(static_cast<unsigned char>(text[p]))) {
                int end = p + 1;
                while (p >= 0 && (std::isdigit(static_cast<unsigned char>(text[p])) || text[p] == '.' || text[p] == ',')) p--;
                distance = std::atof(text.substr(p + 1, end - p - 1).c_str());
            }
        }
    }

    jdoubleArray result = env->NewDoubleArray(4);
    if (result == nullptr) return nullptr;

    jdouble fill[4] = {fare, distance, duration, rating};
    env->SetDoubleArrayRegion(result, 0, 4, fill);
    return result;
}
