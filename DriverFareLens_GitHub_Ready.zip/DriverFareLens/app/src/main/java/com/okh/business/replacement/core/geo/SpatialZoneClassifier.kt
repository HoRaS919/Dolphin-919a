package com.okh.business.replacement.core.geo

data class ZoneEvaluation(
    val zoneName: String,
    val returnQualityScore: Int,
    val returnDescription: String,
    val isDeadheadWarning: Boolean,
    val hasTollGate: Boolean,
    val estimatedTollCost: Double
)

object SpatialZoneClassifier {

    private val HIGH_DEMAND_HUBS = arrayOf(
        "الحصري", "أكتوبر", "الشيخ زايد", "زايد", "المهندسين", "الدقي",
        "الزمالك", "وسط البلد", "المعادي", "التجمع", "مدينة نصر", "الهرم", "فيصل"
    )

    private val REMOTE_DEADHEAD_ZONES = arrayOf(
        "طريق الضبعة", "الواحات العميق", "الصحراوي بعد البوابات", "طريق الفيوم بعد المقابر",
        "دهشور الزراعي", "مزارع طريق مصر اسكندرية", "الحزام الأخضر النائي"
    )

    private val TOLL_GATE_ROUTES = arrayOf(
        "دهشور", "صحراوي", "بوابات", "كارتة", "روض الفرج", "الضبعة", "طريق السويس", "طريق السخنة"
    )

    fun evaluateDestination(addressText: String): ZoneEvaluation {
        if (addressText.isBlank()) {
            return ZoneEvaluation("غير محدد", 3, "منطقة عادية", false, false, 0.0)
        }

        var hasToll = false
        var tollCost = 0.0
        for (toll in TOLL_GATE_ROUTES) {
            if (addressText.contains(toll, ignoreCase = true)) {
                hasToll = true
                tollCost = 25.0
                break
            }
        }

        for (remote in REMOTE_DEADHEAD_ZONES) {
            if (addressText.contains(remote, ignoreCase = true)) {
                return ZoneEvaluation(
                    zoneName = remote,
                    returnQualityScore = 1,
                    returnDescription = "تحذير: منطقة نائية - صعوبة رحلة العودة",
                    isDeadheadWarning = true,
                    hasTollGate = hasToll,
                    estimatedTollCost = tollCost
                )
            }
        }

        for (hub in HIGH_DEMAND_HUBS) {
            if (addressText.contains(hub, ignoreCase = true)) {
                return ZoneEvaluation(
                    zoneName = hub,
                    returnQualityScore = 5,
                    returnDescription = "منطقة نشطة - طلبات عودة مستمرة",
                    isDeadheadWarning = false,
                    hasTollGate = hasToll,
                    estimatedTollCost = tollCost
                )
            }
        }

        return ZoneEvaluation("منطقة عادية", 3, "معدل طلبات عودة متوازن", false, hasToll, tollCost)
    }
}
