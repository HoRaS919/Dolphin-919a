package com.okh.business.replacement.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trip_records")
data class TripRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val platformName: String,
    val fare: Double,
    val currency: String,
    val distanceKm: Double,
    val durationMinutes: Int,
    val ratePerKm: Double,
    val isProfitable: Boolean,
    val status: String = "DETECTED"
)
