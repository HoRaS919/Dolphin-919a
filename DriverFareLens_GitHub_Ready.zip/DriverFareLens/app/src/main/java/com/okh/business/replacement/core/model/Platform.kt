package com.okh.business.replacement.core.model

enum class DriverPlatform(val id: String, val displayName: String, val packageName: String) {
    UBER("uber", "Uber", "com.ubercab"),
    DIDI("didi", "DiDi", "com.didiglobal.passenger"),
    INDRIVER("indriver", "inDrive", "me.indriver"),
    UNKNOWN("unknown", "Unknown", "");

    companion object {
        fun fromPackage(pkg: String): DriverPlatform {
            return entries.firstOrNull { it.packageName == pkg } ?: UNKNOWN
        }
    }
}
