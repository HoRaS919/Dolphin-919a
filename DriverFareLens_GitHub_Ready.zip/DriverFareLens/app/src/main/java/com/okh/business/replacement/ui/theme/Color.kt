package com.okh.business.replacement.ui.theme

import androidx.compose.ui.graphics.Color

val SlateDarkBackground = Color(0xFF0F172A)
val SlateSurface = Color(0xFF1E293B)
val SlateSurfaceVariant = Color(0xFF334155)

val ProfitHigh = Color(0xFF10B981)
val ProfitMedium = Color(0xFFF59E0B)
val ProfitLow = Color(0xFFEF4444)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val AccentBlue = Color(0xFF38BDF8)
val AccentBlueDark = Color(0xFF0284C7)
