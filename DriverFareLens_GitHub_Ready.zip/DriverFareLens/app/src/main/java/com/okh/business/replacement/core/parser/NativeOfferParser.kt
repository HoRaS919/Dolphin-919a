package com.okh.business.replacement.core.parser

import com.okh.business.replacement.core.model.TripCard

object NativeOfferParser {

    private var isNativeLoaded = false

    init {
        try {
            System.loadLibrary("driverfarelens_native")
            isNativeLoaded = true
        } catch (t: Throwable) {
            isNativeLoaded = false
        }
    }

    private external fun parseNativeTokens(rawText: String): DoubleArray?

    fun parseOffer(rawText: String): TripCard? {
        if (isNativeLoaded) {
            try {
                val array = parseNativeTokens(rawText)
                if (array != null && array.size >= 4) {
                    val fare = array[0]
                    val distance = array[1]
                    val duration = array[2].toInt()
                    val rating = array[3]
                    if (fare > 0.0 || distance > 0.0) {
                        return TripCard(fare, distance, duration, rating)
                    }
                }
            } catch (e: Exception) {
                // fallback to FastOfferParser
            }
        }
        return FastOfferParser.parseOffer(rawText)
    }
}
