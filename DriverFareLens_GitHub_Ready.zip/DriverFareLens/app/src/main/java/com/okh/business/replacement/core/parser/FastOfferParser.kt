package com.okh.business.replacement.core.parser

import com.okh.business.replacement.core.model.TripCard

object FastOfferParser {

    private val ARABIC_DIGITS_MAP = mapOf(
        '٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4',
        '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9', '٫' to '.'
    )

    private val CURRENCY_TOKENS = arrayOf("EGP", "LE", "ج.م", "جنيه", "SAR", "AED")
    private val DISTANCE_TOKENS = arrayOf("km", "كم", "كيلو")
    private val TIME_TOKENS = arrayOf("min", "mins", "دقيقة", "د")

    fun parseOffer(rawText: String): TripCard? {
        if (rawText.isBlank()) return null
        val normalized = normalizeDigits(rawText)

        var fare = extractNumberBeforeOrAfterToken(normalized, CURRENCY_TOKENS)
        var distance = extractNumberBeforeOrAfterToken(normalized, DISTANCE_TOKENS)
        val duration = extractNumberBeforeOrAfterToken(normalized, TIME_TOKENS).toInt()

        if (fare == 0.0) {
            fare = extractFirstMoneyValue(normalized)
        }
        val rating = extractRating(normalized)

        return if (fare > 0.0 || distance > 0.0) {
            TripCard(fare, distance, duration, rating)
        } else {
            null
        }
    }

    private fun normalizeDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            sb.append(ARABIC_DIGITS_MAP[ch] ?: ch)
        }
        return sb.toString()
    }

    private fun extractNumberBeforeOrAfterToken(text: String, tokens: Array<String>): Double {
        for (token in tokens) {
            var index = text.indexOf(token, ignoreCase = true)
            while (index != -1) {
                val numberBefore = parseAdjacentNumber(text, index, lookLeft = true)
                if (numberBefore > 0.0) return numberBefore

                val numberAfter = parseAdjacentNumber(text, index + token.length, lookLeft = false)
                if (numberAfter > 0.0) return numberAfter

                index = text.indexOf(token, index + 1, ignoreCase = true)
            }
        }
        return 0.0
    }

    private fun parseAdjacentNumber(text: String, startIdx: Int, lookLeft: Boolean): Double {
        var i = startIdx
        val len = text.length

        if (lookLeft) {
            i--
            while (i >= 0 && text[i].isWhitespace()) i--
            if (i < 0 || !text[i].isDigit()) return 0.0
            val endDigits = i + 1
            while (i >= 0 && (text[i].isDigit() || text[i] == '.' || text[i] == ',')) i--
            val numStr = text.substring(i + 1, endDigits).replace(',', '.')
            return numStr.toDoubleOrNull() ?: 0.0
        } else {
            while (i < len && text[i].isWhitespace()) i++
            if (i >= len || !text[i].isDigit()) return 0.0
            val startDigits = i
            while (i < len && (text[i].isDigit() || text[i] == '.' || text[i] == ',')) i++
            val numStr = text.substring(startDigits, i).replace(',', '.')
            return numStr.toDoubleOrNull() ?: 0.0
        }
    }

    private fun extractFirstMoneyValue(text: String): Double {
        val regex = Regex("\\b(\\d{2,4}(?:\\.\\d{1,2})?)\\b")
        val match = regex.find(text)
        return match?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
    }

    private fun extractRating(text: String): Double {
        val regex = Regex("([45]\\.\\d{1,2})")
        val match = regex.find(text)
        return match?.groupValues?.get(1)?.toDoubleOrNull() ?: 4.85
    }
}
