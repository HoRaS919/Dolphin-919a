package com.okh.business.replacement.core.model

import androidx.compose.runtime.Immutable

@Immutable
data class TripMetrics(
    val platform: DriverPlatform,
    val fare: Double,
    val currency: String = "EGP",
    val distanceKm: Double,
    val durationMinutes: Int,
    val passengerRating: Double,
    val ratePerKm: Double,
    val ratePerMinute: Double,
    val isProfitable: Boolean,
    val destinationAddress: String = "",
    val netPocketProfit: Double = 0.0,
    val platformCommission: Double = 0.0,
    val estimatedFuelCost: Double = 0.0,
    val hasTollGate: Boolean = false,
    val estimatedTollCost: Double = 0.0,
    val destinationZoneDescription: String = "",
    // Passenger Safety Shield
    val isLowRatingWarning: Boolean = false,
    val lowRatingWarningText: String = ""
)
