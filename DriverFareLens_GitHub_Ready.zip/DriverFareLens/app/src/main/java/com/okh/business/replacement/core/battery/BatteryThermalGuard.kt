package com.okh.business.replacement.core.battery

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

class BatteryThermalGuard(
    private val context: Context,
    private val onCriticalThermalAlert: (temperatureCelsius: Float) -> Unit
) {
    private var isRegistered = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_CHANGED) {
                val tempRaw = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
                val tempCelsius = tempRaw / 10.0f

                val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL

                // Alert driver if phone battery reaches dangerous temperatures while plugged to car charger
                if (tempCelsius >= 42.0f && isCharging) {
                    onCriticalThermalAlert(tempCelsius)
                }
            }
        }
    }

    fun startMonitoring() {
        if (!isRegistered) {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            context.registerReceiver(batteryReceiver, filter)
            isRegistered = true
        }
    }

    fun stopMonitoring() {
        if (isRegistered) {
            try {
                context.unregisterReceiver(batteryReceiver)
            } catch (ignored: Exception) {}
            isRegistered = false
        }
    }
}
