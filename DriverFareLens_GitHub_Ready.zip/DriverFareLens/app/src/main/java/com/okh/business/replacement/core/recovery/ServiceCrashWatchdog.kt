package com.okh.business.replacement.core.recovery

import android.util.Log

class ServiceCrashWatchdog(
    private val onRecoveryAction: () -> Unit
) : Thread.UncaughtExceptionHandler {

    private val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()

    override fun uncaughtException(t: Thread, e: Throwable) {
        Log.e("ServiceCrashWatchdog", "Critical exception intercepted in service thread: ${t.name}", e)
        try {
            onRecoveryAction()
            Log.i("ServiceCrashWatchdog", "Self-healing recovery action executed successfully.")
        } catch (recoveryException: Throwable) {
            Log.e("ServiceCrashWatchdog", "Failed during recovery attempt", recoveryException)
        }
    }

    companion object {
        fun install(onRecovery: () -> Unit) {
            val watchdog = ServiceCrashWatchdog(onRecovery)
            Thread.setDefaultUncaughtExceptionHandler(watchdog)
        }
    }
}
