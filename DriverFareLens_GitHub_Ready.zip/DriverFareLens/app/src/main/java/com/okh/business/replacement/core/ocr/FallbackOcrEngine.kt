package com.okh.business.replacement.core.ocr

import android.graphics.Bitmap
import android.media.Image
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class FallbackOcrEngine {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    /**
     * Zero-Copy Pipeline: Ingests directly from hardware camera / virtual display Image plane
     * without generating an intermediate 15MB Bitmap on the Java Heap.
     */
    suspend fun recognizeMediaImageText(mediaImage: Image, rotationDegrees: Int = 0): String = withContext(Dispatchers.Default) {
        try {
            val image = InputImage.fromMediaImage(mediaImage, rotationDegrees)
            val result = recognizer.process(image).await()
            result.text
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    suspend fun recognizeBitmapText(bitmap: Bitmap, rotationDegrees: Int = 0): String = withContext(Dispatchers.Default) {
        try {
            val image = InputImage.fromBitmap(bitmap, rotationDegrees)
            val result = recognizer.process(image).await()
            result.text
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    fun close() {
        recognizer.close()
    }
}
