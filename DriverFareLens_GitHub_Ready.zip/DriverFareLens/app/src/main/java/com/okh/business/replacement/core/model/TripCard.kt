package com.okh.business.replacement.core.model

import androidx.compose.runtime.Immutable

@Immutable
data class TripCard(
    val fare: Double,
    val distanceKm: Double,
    val durationMinutes: Int,
    val rating: Double = 4.8,
    val pickupAddress: String = "",
    val destinationAddress: String = ""
)
