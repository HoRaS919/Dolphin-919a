package com.okh.business.replacement

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.okh.business.replacement.core.battery.BatteryThermalGuard
import com.okh.business.replacement.core.geo.OctoberSurgeRadar
import com.okh.business.replacement.data.db.AppDatabase
import com.okh.business.replacement.ipc.ITripServiceAidlInterface
import com.okh.business.replacement.ui.components.ProminentDisclosureDialog
import com.okh.business.replacement.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    private var tripAidlService: ITripServiceAidlInterface? = null
    private var isBound = false
    private var batteryThermalGuard: BatteryThermalGuard? = null

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            tripAidlService = ITripServiceAidlInterface.Stub.asInterface(service)
            isBound = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            tripAidlService = null
            isBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bindTripService()

        batteryThermalGuard = BatteryThermalGuard(this) { tempCelsius ->
            // In a production car mount, notify driver to unplug charger safely
        }.also { it.startMonitoring() }

        setContent {
            DriverFareLensTheme {
                MainScreen(
                    onEnableAccessibility = {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    },
                    onVoiceSwitchChanged = { enabled ->
                        try {
                            tripAidlService?.setVoiceAssistantEnabled(enabled)
                        } catch (ignored: Exception) {}
                    }
                )
            }
        }
    }

    private fun bindTripService() {
        val intent = Intent(this, TripAccessibilityService::class.java).apply {
            action = "com.okh.business.replacement.ACTION_BIND_SERVICE"
        }
        try {
            bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        } catch (ignored: Exception) {}
    }

    override fun onDestroy() {
        batteryThermalGuard?.stopMonitoring()
        if (isBound) {
            try {
                unbindService(serviceConnection)
            } catch (ignored: Exception) {}
            isBound = false
        }
        super.onDestroy()
    }
}

fun checkAccessibilityServiceActive(context: Context): Boolean {
    val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
    val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
    val targetComponent = ComponentName(context, TripAccessibilityService::class.java)

    for (service in enabledServices) {
        val resolveInfo = service.resolveInfo ?: continue
        if (resolveInfo.serviceInfo.packageName == targetComponent.packageName &&
            resolveInfo.serviceInfo.name == targetComponent.className) {
            return true
        }
    }
    return false
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    onEnableAccessibility: () -> Unit,
    onVoiceSwitchChanged: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("driver_fare_lens_prefs", Context.MODE_PRIVATE) }

    var showDisclosure by remember { mutableStateOf(false) }
    var voiceEnabled by remember {
        mutableStateOf(prefs.getBoolean("voice_assistant_enabled", true))
    }
    var dailyTargetEgp by remember {
        mutableStateOf(prefs.getInt("daily_target_egp", 1000))
    }

    var isAccessibilityActive by remember { mutableStateOf(false) }
    var todayOffersCount by remember { mutableStateOf(0) }
    var profitableCount by remember { mutableStateOf(0) }
    var avgRatePerKm by remember { mutableStateOf(0.0) }
    var estimatedTotalProfit by remember { mutableStateOf(0.0) }

    val surgeStatus = remember { OctoberSurgeRadar.getCurrentSurgeStatus() }

    LaunchedEffect(Unit) {
        isAccessibilityActive = checkAccessibilityServiceActive(context)

        withContext(Dispatchers.IO) {
            val dao = AppDatabase.getDatabase(context).tripDao()
            val startOfDay = System.currentTimeMillis() - 86400000L
            todayOffersCount = dao.getTodayOffersCount(startOfDay)
            profitableCount = dao.getTodayProfitableCount(startOfDay)
            avgRatePerKm = Math.round(dao.getTodayAverageRatePerKm(startOfDay) * 10.0) / 10.0
            estimatedTotalProfit = profitableCount * 75.0 // ~75 EGP net estimate per accepted trip
        }
    }

    val progressPercent = ((estimatedTotalProfit / dailyTargetEgp) * 100).toInt().coerceIn(0, 100)

    Scaffold(
        containerColor = SlateDarkBackground,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.DirectionsCar,
                            contentDescription = null,
                            tint = AccentBlue
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Driver Fare Lens",
                            color = TextPrimaryDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SlateSurface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Status Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = SlateSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isAccessibilityActive) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (isAccessibilityActive) ProfitHigh else ProfitMedium,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = if (isAccessibilityActive) "نظام التحليل نشط ومستعد" else "خدمة الرصد غير مفعلة",
                            color = TextPrimaryDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = if (isAccessibilityActive)
                                "خدمة قراءة الرحلات مفعلة وتعمل في الخلفية"
                            else
                                "يرجى الضغط بالأسفل لمنح صلاحية إمكانية الوصول",
                            color = TextSecondaryDark,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // October & Giza Surge Radar Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = SlateSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bolt, contentDescription = null, tint = ProfitMedium)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "رادار الذروة (6 أكتوبر والجيزة)",
                                color = TextPrimaryDark,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                        if (surgeStatus.isSurgeActive) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(ProfitMedium.copy(alpha = 0.2f))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = surgeStatus.expectedMultiplier,
                                    color = ProfitMedium,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = surgeStatus.title,
                        color = TextPrimaryDark,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = surgeStatus.description,
                        color = TextSecondaryDark,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            // Daily Financial Target HUD Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = SlateSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AttachMoney, contentDescription = null, tint = ProfitHigh)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "هدف الوردية اليومي",
                                color = TextPrimaryDark,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                        Text(
                            text = "$progressPercent%",
                            color = ProfitHigh,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = progressPercent / 100f,
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = ProfitHigh,
                        trackColor = SlateSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "تم تحقيق: ${estimatedTotalProfit.toInt()} ج.م",
                            color = TextSecondaryDark,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "الهدف: $dailyTargetEgp ج.م",
                            color = TextPrimaryDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Shift Analytics Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = SlateSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Analytics, contentDescription = null, tint = AccentBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إحصائيات وردية اليوم",
                            color = TextPrimaryDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ShiftMetricItem(title = "العروض الملتقطة", value = "$todayOffersCount")
                        ShiftMetricItem(title = "العروض المربحة", value = "$profitableCount", highlight = ProfitHigh)
                        ShiftMetricItem(title = "متوسط لكل كم", value = "$avgRatePerKm ج.م")
                    }
                }
            }

            // Voice Assistant Feature Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = SlateSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(AccentBlue.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = AccentBlue)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "المساعد الصوتي للقيادة (TTS)",
                                color = TextPrimaryDark,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "نطق ملخص العرض تلقائياً مع خفض الموسيقى",
                                color = TextSecondaryDark,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Switch(
                        checked = voiceEnabled,
                        onCheckedChange = { newState ->
                            voiceEnabled = newState
                            prefs.edit().putBoolean("voice_assistant_enabled", newState).apply()
                            onVoiceSwitchChanged(newState)
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentBlue)
                    )
                }
            }

            // Quick Setup Action Button
            Button(
                onClick = { showDisclosure = true },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isAccessibilityActive) SlateSurfaceVariant else AccentBlue
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = if (isAccessibilityActive) TextPrimaryDark else SlateDarkBackground
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isAccessibilityActive) "إعدادات إمكانية الوصول (مُفعل بالفعل)" else "تفعيل خدمة إمكانية الوصول الآن",
                    color = if (isAccessibilityActive) TextPrimaryDark else SlateDarkBackground,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }

        if (showDisclosure) {
            ProminentDisclosureDialog(
                onAccept = {
                    showDisclosure = false
                    onEnableAccessibility()
                },
                onDismiss = { showDisclosure = false }
            )
        }
    }
}

@Composable
private fun ShiftMetricItem(
    title: String,
    value: String,
    highlight: androidx.compose.ui.graphics.Color = TextPrimaryDark
) {
    Column(horizontalAlignment = Alignment.Start) {
        Text(text = title, color = TextSecondaryDark, fontSize = 11.sp)
        Text(
            text = value,
            color = highlight,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )
    }
}
