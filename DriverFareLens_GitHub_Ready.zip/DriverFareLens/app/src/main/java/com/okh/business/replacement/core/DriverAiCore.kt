package com.okh.business.replacement.core

import android.content.Context
import com.okh.business.replacement.core.model.DriverPlatform
import com.okh.business.replacement.core.model.TripMetrics
import com.okh.business.replacement.core.parser.FastOfferParser
import com.okh.business.replacement.data.db.AppDatabase
import com.okh.business.replacement.data.db.TripRecord
import com.okh.business.replacement.voice.DriverVoiceAssistant
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class DriverAiCore(
    context: Context? = null,
    private val smartRouteEngine: SmartRouteEngine = SmartRouteEngine(),
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default
) {
    private val coroutineScope = CoroutineScope(SupervisorJob() + dispatcher)
    private val tripDao = context?.let { AppDatabase.getDatabase(it).tripDao() }
    val voiceAssistant = context?.let { DriverVoiceAssistant(it) }

    private val _currentMetrics = MutableStateFlow<TripMetrics?>(null)
    val currentMetrics: StateFlow<TripMetrics?> = _currentMetrics.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    fun evaluateScreenOffer(rawText: String, packageName: String) {
        if (rawText.isBlank()) return

        coroutineScope.launch {
            _isProcessing.value = true
            try {
                val platform = DriverPlatform.fromPackage(packageName)
                // Single source of truth for parsing
                val card = FastOfferParser.parseOffer(rawText)

                if (card != null && (card.fare > 0 || card.distanceKm > 0)) {
                    val metrics = smartRouteEngine.calculateMetrics(card, platform)
                    _currentMetrics.value = metrics

                    // Voice announcement (triggers microphone listener after speech completes)
                    voiceAssistant?.announceOffer(metrics)

                    tripDao?.insertTrip(
                        TripRecord(
                            platformName = platform.displayName,
                            fare = metrics.fare,
                            currency = metrics.currency,
                            distanceKm = metrics.distanceKm,
                            durationMinutes = metrics.durationMinutes,
                            ratePerKm = metrics.ratePerKm,
                            isProfitable = metrics.isProfitable
                        )
                    )
                }
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun dismissCurrentOffer() {
        _currentMetrics.value = null
    }

    fun clearVolatileCaches() {
        _currentMetrics.value = null
    }

    fun release() {
        voiceAssistant?.shutdown()
        coroutineScope.cancel()
    }
}
