package com.okh.business.replacement.core

import com.okh.business.replacement.core.geo.SpatialZoneClassifier
import com.okh.business.replacement.core.model.DriverPlatform
import com.okh.business.replacement.core.model.TripCard
import com.okh.business.replacement.core.model.TripMetrics
import kotlin.math.round

class SmartRouteEngine(
    var minAcceptableRatePerKm: Double = 10.0,
    var currency: String = "EGP",
    var lowRatingThreshold: Double = 4.70
) {
    fun calculateMetrics(card: TripCard, platform: DriverPlatform): TripMetrics {
        val safeDistance = if (card.distanceKm > 0.05) card.distanceKm else 1.0
        val safeDuration = if (card.durationMinutes > 0) card.durationMinutes else 1

        val rawRatePerKm = card.fare / safeDistance
        val rawRatePerMin = card.fare / safeDuration

        val roundedRatePerKm = round(rawRatePerKm * 10.0) / 10.0
        val roundedRatePerMin = round(rawRatePerMin * 10.0) / 10.0

        val commissionRate = when (platform) {
            DriverPlatform.UBER -> 0.22
            DriverPlatform.DIDI -> 0.16
            DriverPlatform.INDRIVER -> 0.10
            else -> 0.20
        }

        val platformCommission = round((card.fare * commissionRate) * 10.0) / 10.0
        val fuelCostPerKm = 0.08 * 14.0 // ~1.12 EGP / km (Octane 92)
        val estimatedFuelCost = round((safeDistance * fuelCostPerKm) * 10.0) / 10.0

        val zoneEval = SpatialZoneClassifier.evaluateDestination(card.destinationAddress)
        val netPocketProfit = round((card.fare - platformCommission - estimatedFuelCost - zoneEval.estimatedTollCost) * 10.0) / 10.0

        // Low-rating passenger shield
        val isLowRating = card.rating in 1.0..lowRatingThreshold
        val lowRatingText = if (isLowRating) {
            "⚠️ راكب منخفض التقييم (${card.rating}★) - يُنصح بالحذر"
        } else ""

        val isProfitable = roundedRatePerKm >= minAcceptableRatePerKm && !zoneEval.isDeadheadWarning && !isLowRating

        return TripMetrics(
            platform = platform,
            fare = card.fare,
            currency = currency,
            distanceKm = card.distanceKm,
            durationMinutes = card.durationMinutes,
            passengerRating = card.rating,
            ratePerKm = roundedRatePerKm,
            ratePerMinute = roundedRatePerMin,
            isProfitable = isProfitable,
            destinationAddress = card.destinationAddress,
            netPocketProfit = netPocketProfit,
            platformCommission = platformCommission,
            estimatedFuelCost = estimatedFuelCost,
            hasTollGate = zoneEval.hasTollGate,
            estimatedTollCost = zoneEval.estimatedTollCost,
            destinationZoneDescription = zoneEval.returnDescription,
            isLowRatingWarning = isLowRating,
            lowRatingWarningText = lowRatingText
        )
    }
}
