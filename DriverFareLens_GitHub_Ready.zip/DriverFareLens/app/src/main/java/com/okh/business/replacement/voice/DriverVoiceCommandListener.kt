package com.okh.business.replacement.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.content.ContextCompat

class DriverVoiceCommandListener(
    context: Context,
    private val onCommandReceived: (String) -> Unit
) : RecognitionListener {

    private val applicationContext = context.applicationContext
    private var recognizer: SpeechRecognizer? = null
    var isListening: Boolean = false
        private set

    fun startListening() {
        // Runtime Permission Guard: Prevents SecurityException crash if permission not granted
        val hasPermission = ContextCompat.checkSelfPermission(
            applicationContext,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPermission) {
            Log.w("VoiceCommandListener", "RECORD_AUDIO permission not granted. Skipping voice commands safely.")
            return
        }

        if (recognizer == null) {
            if (!SpeechRecognizer.isRecognitionAvailable(applicationContext)) return
            recognizer = SpeechRecognizer.createSpeechRecognizer(applicationContext).apply {
                setRecognitionListener(this@DriverVoiceCommandListener)
            }
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }

        try {
            recognizer?.startListening(intent)
            isListening = true
        } catch (e: Exception) {
            Log.e("VoiceCommandListener", "Speech recognition failed to start", e)
        }
    }

    fun stopListening() {
        try {
            recognizer?.stopListening()
            recognizer?.destroy()
            recognizer = null
            isListening = false
        } catch (ignored: Exception) {}
    }

    override fun onResults(results: Bundle?) {
        isListening = false
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            for (match in matches) {
                val command = match.trim().lowercase()
                if (command.contains("كرر") || command.contains("عيد") || command.contains("repeat")) {
                    onCommandReceived("REPEAT")
                    return
                } else if (command.contains("إغلاق") || command.contains("تخطي") || command.contains("dismiss")) {
                    onCommandReceived("DISMISS")
                    return
                }
            }
        }
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { isListening = false }
    override fun onError(error: Int) { isListening = false }
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
