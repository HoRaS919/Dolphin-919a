package com.okh.business.replacement.core.bluetooth

import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class BluetoothCarTriggerReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
        val deviceName = try { device?.name ?: "Unknown" } catch (e: SecurityException) { "Protected" }

        when (action) {
            BluetoothDevice.ACTION_ACL_CONNECTED -> {
                Log.i("BluetoothCarTrigger", "Bluetooth connected: $deviceName. Auto-activating Drive Mode.")
                // Notify system or broadcast intent to wake Drive Mode overlay
                val wakeIntent = Intent("com.okh.business.replacement.ACTION_CAR_CONNECTED")
                context.sendBroadcast(wakeIntent)
            }
            BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                Log.i("BluetoothCarTrigger", "Bluetooth disconnected: $deviceName. Standing down.")
            }
        }
    }
}
