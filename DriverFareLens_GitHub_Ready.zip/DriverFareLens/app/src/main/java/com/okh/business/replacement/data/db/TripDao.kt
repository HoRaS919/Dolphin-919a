package com.okh.business.replacement.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TripDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrip(trip: TripRecord): Long

    @Query("SELECT * FROM trip_records ORDER BY timestamp DESC LIMIT 50")
    fun getRecentTrips(): Flow<List<TripRecord>>

    @Query("SELECT COUNT(*) FROM trip_records WHERE timestamp >= :sinceTime")
    suspend fun getTodayOffersCount(sinceTime: Long): Int

    @Query("SELECT COUNT(*) FROM trip_records WHERE timestamp >= :sinceTime AND isProfitable = 1")
    suspend fun getTodayProfitableCount(sinceTime: Long): Int

    @Query("SELECT COALESCE(AVG(ratePerKm), 0.0) FROM trip_records WHERE timestamp >= :sinceTime")
    suspend fun getTodayAverageRatePerKm(sinceTime: Long): Double

    @Query("DELETE FROM trip_records WHERE timestamp < :olderThanTime")
    suspend fun pruneOldRecords(olderThanTime: Long)
}
