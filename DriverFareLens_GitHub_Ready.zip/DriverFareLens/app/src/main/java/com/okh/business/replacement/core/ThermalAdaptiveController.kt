package com.okh.business.replacement.core

import android.content.Context
import android.os.Build
import android.os.PowerManager

class ThermalAdaptiveController(context: Context) {
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager

    /**
     * Predictive throttle: predicts device temperature in the next 10 seconds (Android 11+ R)
     * to throttle frame inspection before thermal throttling triggers hardware clock drops.
     */
    fun getInspectionThrottleMillis(): Long {
        if (powerManager == null) return 250L

        if (powerManager.isPowerSaveMode) {
            return 800L
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                // Forecast thermal headroom 10 seconds into the future
                val headroom = powerManager.getThermalHeadroom(10)
                if (headroom >= 0.90f) {
                    return 900L // Heavy throttling: critical temperature imminent
                } else if (headroom >= 0.75f) {
                    return 500L // Moderate throttling
                } else if (headroom < 0.40f) {
                    return 160L // Maximum responsiveness: cool temperature
                }
            } catch (e: Exception) {
                // Fallback to legacy status
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return when (powerManager.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE,
                PowerManager.THERMAL_STATUS_LIGHT -> 200L
                PowerManager.THERMAL_STATUS_MODERATE -> 450L
                PowerManager.THERMAL_STATUS_SEVERE,
                PowerManager.THERMAL_STATUS_CRITICAL -> 900L
                else -> 350L
            }
        }
        return 300L
    }

    fun isDeviceThermalCritical(): Boolean {
        if (powerManager == null) return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                return powerManager.getThermalHeadroom(5) >= 0.92f
            } catch (ignored: Exception) {}
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return powerManager.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE
        }
        return false
    }
}
