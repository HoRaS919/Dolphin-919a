package com.okh.business.replacement.core.geo

import java.util.Calendar

data class SurgeStatus(
    val isSurgeActive: Boolean,
    val title: String,
    val description: String,
    val expectedMultiplier: String
)

object OctoberSurgeRadar {

    fun getCurrentSurgeStatus(): SurgeStatus {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        val totalMinutes = hour * 60 + minute

        return when {
            // Morning Commute: 7:00 AM to 9:30 AM (420 to 570 mins)
            totalMinutes in 420..570 -> SurgeStatus(
                isSurgeActive = true,
                title = "⚡ ذروة الصباح: خروج المحور والدائري",
                description = "طلبات مكثفة من 6 أكتوبر والشيخ زايد باتجاه المهندسين، الدقي، ووسط البلد.",
                expectedMultiplier = "1.3x - 1.5x"
            )

            // University Exodus: 1:30 PM to 5:00 PM (810 to 1020 mins)
            totalMinutes in 810..1020 -> SurgeStatus(
                isSurgeActive = true,
                title = "🎓 ذروة خروج جامعات 6 أكتوبر",
                description = "انصراف طلاب جامعات MUST، MSA، جامعة 6 أكتوبر، والنيل باتجاه الجيزة والهرم.",
                expectedMultiplier = "1.4x - 1.7x"
            )

            // Smart Village & Industrial Zones: 4:30 PM to 7:30 PM (990 to 1170 mins)
            totalMinutes in 990..1170 -> SurgeStatus(
                isSurgeActive = true,
                title = "🏢 ذروة انصراف القرية الذكية والمنطقة الصناعية",
                description = "خروج موظفي الشركات والمنطقة الصناعية بالسادس من أكتوبر باتجاه المحاور الرئيسية.",
                expectedMultiplier = "1.5x - 1.8x"
            )

            // Evening Leisure & Malls: 8:00 PM to 11:30 PM (1200 to 1410 mins)
            totalMinutes in 1200..1410 -> SurgeStatus(
                isSurgeActive = true,
                title = "🛍️ ذروة المساء: مولات وخروجات زايد وأكتوبر",
                description = "نشاط عالي حول مول العرب، مول مصر، وأركان بلازا والشيخ زايد.",
                expectedMultiplier = "1.2x - 1.4x"
            )

            else -> SurgeStatus(
                isSurgeActive = false,
                title = "حركة مرورية معتدلة",
                description = "حركة التنقل طبيعية ومستقرة حالياً في نطاق 6 أكتوبر والشيخ زايد والجيزة.",
                expectedMultiplier = "1.0x"
            )
        }
    }
}
