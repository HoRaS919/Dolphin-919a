package com.okh.business.replacement.ui.overlay

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.okh.business.replacement.core.model.TripMetrics
import com.okh.business.replacement.ui.theme.*

@Composable
fun DriveModeFloatingCard(
    metrics: TripMetrics,
    onCloseClick: () -> Unit,
    onAcceptClick: () -> Unit,
    onOpenMapsClick: () -> Unit,
    onReplaySpeech: () -> Unit,
    onDragAmount: ((dx: Float, dy: Float) -> Unit)? = null,
    onDragEnd: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var isStealthMode by remember { mutableStateOf(false) }
    var showNetBreakdown by remember { mutableStateOf(false) }

    val profitColor = when {
        metrics.isLowRatingWarning -> ProfitLow
        metrics.ratePerKm >= 12.0 -> ProfitHigh
        metrics.ratePerKm >= 8.0 -> ProfitMedium
        else -> ProfitLow
    }

    val profitBadgeText = when {
        metrics.isLowRatingWarning -> "راكب مقلق"
        metrics.isProfitable -> "عرض مربح"
        else -> "ربح منخفض"
    }

    if (isStealthMode) {
        Box(
            modifier = modifier
                .size(52.dp)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDrag = { change, dragAmount ->
                            change.consume()
                            onDragAmount?.invoke(dragAmount.x, dragAmount.y)
                        },
                        onDragEnd = { onDragEnd?.invoke() }
                    )
                }
                .clip(CircleShape)
                .background(SlateSurface)
                .border(2.5.dp, profitColor, CircleShape)
                .clickable { isStealthMode = false },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.DirectionsCar,
                contentDescription = "Expand Card",
                tint = profitColor,
                modifier = Modifier.size(24.dp)
            )
        }
    } else {
        Box(
            modifier = modifier
                .animateContentSize()
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDrag = { change, dragAmount ->
                            change.consume()
                            onDragAmount?.invoke(dragAmount.x, dragAmount.y)
                        },
                        onDragEnd = { onDragEnd?.invoke() }
                    )
                }
                .clip(RoundedCornerShape(18.dp))
                .background(SlateSurface.copy(alpha = 0.96f))
                .border(1.2.dp, SlateSurfaceVariant, RoundedCornerShape(18.dp))
                .padding(14.dp)
                .width(285.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.DirectionsCar,
                            contentDescription = null,
                            tint = AccentBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = metrics.platform.displayName,
                            color = TextPrimaryDark,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onReplaySpeech, modifier = Modifier.size(26.dp)) {
                            Icon(Icons.Default.VolumeUp, contentDescription = "Replay", tint = AccentBlue, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = { isStealthMode = true }, modifier = Modifier.size(26.dp)) {
                            Icon(Icons.Default.VisibilityOff, contentDescription = "Stealth", tint = TextSecondaryDark, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = onCloseClick, modifier = Modifier.size(26.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = TextSecondaryDark, modifier = Modifier.size(16.dp))
                        }
                    }
                }

                // Low-Rating Passenger Alert
                if (metrics.isLowRatingWarning) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(ProfitLow.copy(alpha = 0.18f))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = ProfitLow, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = metrics.lowRatingWarningText,
                            color = ProfitLow,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Toll Gate Alert
                if (metrics.hasTollGate) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(ProfitMedium.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = ProfitMedium, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "⚠️ كارتة محتملة (+${metrics.estimatedTollCost.toInt()} ج.م)",
                            color = ProfitMedium,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Fare & Rating
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showNetBreakdown = !showNetBreakdown },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "المبلغ الإجمالي", color = TextSecondaryDark, fontSize = 11.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "▾ صافي الجيب", color = AccentBlue, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Text(
                            text = "${metrics.fare} ${metrics.currency}",
                            color = TextPrimaryDark,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (metrics.isLowRatingWarning) ProfitLow.copy(alpha = 0.25f) else SlateSurfaceVariant)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = if (metrics.isLowRatingWarning) ProfitLow else ProfitMedium,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${metrics.passengerRating}",
                            color = if (metrics.isLowRatingWarning) ProfitLow else TextPrimaryDark,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Expandable Net Profit Breakdown
                AnimatedVisibility(visible = showNetBreakdown) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(SlateDarkBackground.copy(alpha = 0.6f))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = "صافي ربحك في الجيب: ~${metrics.netPocketProfit} ${metrics.currency}",
                            color = ProfitHigh,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "عمولة المنصة: -${metrics.platformCommission} | البنزين: -${metrics.estimatedFuelCost}",
                            color = TextSecondaryDark,
                            fontSize = 10.sp
                        )
                    }
                }

                HorizontalDivider(color = SlateSurfaceVariant, thickness = 1.dp)

                // Distance, Time & Profitability
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MetricItem(title = "المسافة", value = "${metrics.distanceKm} كم")
                    MetricItem(title = "الزمن", value = "${metrics.durationMinutes} دقيقة")
                    MetricItem(
                        title = "لكل كم",
                        value = "${metrics.ratePerKm} ${metrics.currency}",
                        highlightColor = profitColor
                    )
                }

                // Action Buttons: Maps & Accept
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onOpenMapsClick,
                        modifier = Modifier.weight(1f).height(38.dp),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentBlue)
                    ) {
                        Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("الخريطة", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = onAcceptClick,
                        modifier = Modifier.weight(1.5f).height(38.dp),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ProfitHigh)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = SlateDarkBackground, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("قبول فوري", color = SlateDarkBackground, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricItem(
    title: String,
    value: String,
    highlightColor: Color = TextPrimaryDark
) {
    Column(horizontalAlignment = Alignment.Start) {
        Text(text = title, color = TextSecondaryDark, fontSize = 11.sp)
        Text(
            text = value,
            color = highlightColor,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
