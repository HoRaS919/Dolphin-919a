package com.okh.business.replacement.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [TripRecord::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun tripDao(): TripDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "driver_fare_lens.db"
                )
                // Multi-Process Synchronization: Syncs SQLite table invalidation
                // between ':core_overlay_service' and the main app process
                .enableMultiInstanceInvalidation()
                .build()

                INSTANCE = instance
                instance
            }
        }
    }
}
