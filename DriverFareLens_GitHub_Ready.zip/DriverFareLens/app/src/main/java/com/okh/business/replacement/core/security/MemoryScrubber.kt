package com.okh.business.replacement.core.security

import java.nio.ByteBuffer
import java.util.Arrays

/**
 * Memory hygiene utility: instantly zeroes out in-memory text buffers to prevent PII or scanned
 * screen tokens from lingering on the ART Heap.
 */
object MemoryScrubber {

    fun scrub(charArray: CharArray?) {
        if (charArray != null) {
            Arrays.fill(charArray, '\u0000')
        }
    }

    fun scrub(buffer: ByteBuffer?) {
        if (buffer != null) {
            val pos = buffer.position()
            buffer.clear()
            while (buffer.hasRemaining()) {
                buffer.put(0.toByte())
            }
            buffer.position(pos)
        }
    }
}
