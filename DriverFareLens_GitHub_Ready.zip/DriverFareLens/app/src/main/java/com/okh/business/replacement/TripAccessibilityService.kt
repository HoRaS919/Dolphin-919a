package com.okh.business.replacement

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.net.Uri
import android.os.IBinder
import android.view.Choreographer
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.ComposeView
import com.okh.business.replacement.core.DriverAiCore
import com.okh.business.replacement.core.ThermalAdaptiveController
import com.okh.business.replacement.core.recovery.ServiceCrashWatchdog
import com.okh.business.replacement.ipc.ITripServiceAidlInterface
import com.okh.business.replacement.ui.overlay.DriveModeFloatingCard
import com.okh.business.replacement.ui.overlay.OverlayLifecycleOwner
import com.okh.business.replacement.ui.theme.DriverFareLensTheme
import com.okh.business.replacement.voice.DriverVoiceCommandListener
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel

data class ScreenInspectionTask(
    val rawText: String,
    val packageName: String,
    val windowBounds: Rect?
)

class TripAccessibilityService : AccessibilityService() {

    private lateinit var windowManager: WindowManager
    private var overlayComposeView: ComposeView? = null
    private var overlayLifecycleOwner: OverlayLifecycleOwner? = null
    private var currentLayoutParams: WindowManager.LayoutParams? = null

    private lateinit var driverAiCore: DriverAiCore
    private lateinit var thermalController: ThermalAdaptiveController
    private var voiceCommandListener: DriverVoiceCommandListener? = null
    private var lastInspectionTime = 0L

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val taskChannel = Channel<ScreenInspectionTask>(
        capacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    private val TARGET_VIEW_IDS = arrayOf(
        "com.ubercab:id/ub__fare_value",
        "com.ubercab:id/ub__trip_distance",
        "com.didiglobal.passenger:id/fare_text",
        "me.indriver:id/order_cost_text",
        "me.indriver:id/order_distance_text"
    )

    private val aidlBinder = object : ITripServiceAidlInterface.Stub() {
        override fun setVoiceAssistantEnabled(enabled: Boolean) {
            driverAiCore.voiceAssistant?.isEnabled = enabled
        }

        override fun isVoiceAssistantEnabled(): Boolean {
            return driverAiCore.voiceAssistant?.isEnabled ?: true
        }

        override fun dismissOverlay() {
            driverAiCore.dismissCurrentOffer()
            removeOverlay()
        }

        override fun getLatestMetricsSummary(): String {
            val m = driverAiCore.currentMetrics.value ?: return "No active offer"
            return "${m.platform.displayName}: ${m.fare} ${m.currency} (${m.ratePerKm}/km)"
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        thermalController = ThermalAdaptiveController(this)
        driverAiCore = DriverAiCore(this)

        val prefs = getSharedPreferences("driver_fare_lens_prefs", Context.MODE_PRIVATE)
        val initialVoiceEnabled = prefs.getBoolean("voice_assistant_enabled", true)
        driverAiCore.voiceAssistant?.isEnabled = initialVoiceEnabled

        ServiceCrashWatchdog.install {
            driverAiCore.clearVolatileCaches()
            removeOverlay()
        }

        voiceCommandListener = DriverVoiceCommandListener(this) { command ->
            when (command) {
                "REPEAT" -> driverAiCore.currentMetrics.value?.let { driverAiCore.voiceAssistant?.announceOffer(it) }
                "DISMISS" -> {
                    driverAiCore.dismissCurrentOffer()
                    removeOverlay()
                }
            }
        }

        driverAiCore.voiceAssistant?.onSpeechDoneCallback = {
            voiceCommandListener?.startListening()
        }

        startConflatedConsumer()
    }

    override fun onBind(intent: Intent?): IBinder? {
        if (intent?.action == "com.okh.business.replacement.ACTION_BIND_SERVICE") {
            return aidlBinder
        }
        return super.onBind(intent)
    }

    private fun startConflatedConsumer() {
        serviceScope.launch {
            for (task in taskChannel) {
                driverAiCore.evaluateScreenOffer(task.rawText, task.packageName)
                withContext(Dispatchers.Main) {
                    scheduleOverlayAtNextVsync(task.windowBounds)
                }
            }
        }
    }

    private fun scheduleOverlayAtNextVsync(windowBounds: Rect?) {
        Choreographer.getInstance().postFrameCallback {
            showOrUpdateOverlay(windowBounds)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val currentTime = System.currentTimeMillis()
        val throttle = thermalController.getInspectionThrottleMillis()
        if (currentTime - lastInspectionTime < throttle) return
        lastInspectionTime = currentTime

        val rootNode = rootInActiveWindow ?: return
        val packageName = event.packageName?.toString() ?: ""

        val windowBounds = Rect()
        try {
            rootNode.getBoundsInScreen(windowBounds)
        } catch (ignored: Exception) {}

        val fastExtracted = tryDirectViewIdExtraction(rootNode)
        val extractedText = if (fastExtracted.isNotBlank()) {
            fastExtracted
        } else {
            val sb = StringBuilder()
            collectNodeText(rootNode, sb)
            sb.toString()
        }

        if (extractedText.isNotBlank()) {
            taskChannel.trySend(ScreenInspectionTask(extractedText, packageName, windowBounds))
        }
    }

    private fun tryDirectViewIdExtraction(rootNode: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        for (viewId in TARGET_VIEW_IDS) {
            val nodes = rootNode.findAccessibilityNodeInfosByViewId(viewId)
            if (!nodes.isNullOrEmpty()) {
                for (node in nodes) {
                    node.text?.let { sb.append(it).append(" ") }
                }
            }
        }
        return sb.toString()
    }

    private fun collectNodeText(node: AccessibilityNodeInfo?, builder: StringBuilder) {
        if (node == null) return
        node.text?.let { builder.append(it).append(" ") }
        node.contentDescription?.let { builder.append(it).append(" ") }
        for (i in 0 until node.childCount) {
            collectNodeText(node.getChild(i), builder)
        }
    }

    private fun showOrUpdateOverlay(windowBounds: Rect? = null) {
        val targetY = if (windowBounds != null && windowBounds.top > 200) {
            windowBounds.top + 50
        } else {
            120
        }

        if (overlayComposeView == null) {
            val lifecycleOwner = OverlayLifecycleOwner().also {
                it.onCreate()
                overlayLifecycleOwner = it
            }

            val view = ComposeView(this).apply {
                lifecycleOwner.attachTo(this)
                setContent {
                    DriverFareLensTheme {
                        val metrics by driverAiCore.currentMetrics.collectAsState()
                        metrics?.let {
                            DriveModeFloatingCard(
                                metrics = it,
                                onCloseClick = {
                                    driverAiCore.dismissCurrentOffer()
                                    removeOverlay()
                                },
                                onAcceptClick = {
                                    performOneTapAcceptGesture()
                                },
                                onOpenMapsClick = {
                                    openInGoogleMaps(it.destinationAddress)
                                },
                                onReplaySpeech = {
                                    driverAiCore.voiceAssistant?.announceOffer(it)
                                },
                                onDragAmount = { dx, dy ->
                                    currentLayoutParams?.let { params ->
                                        params.x += dx.toInt()
                                        params.y += dy.toInt()
                                        try {
                                            windowManager.updateViewLayout(overlayComposeView, params)
                                        } catch (ignored: Exception) {}
                                    }
                                },
                                onDragEnd = {
                                    currentLayoutParams?.let { params ->
                                        val displayMetrics = resources.displayMetrics
                                        val screenWidth = displayMetrics.widthPixels
                                        params.x = if (params.x > 0) (screenWidth / 3) else -(screenWidth / 3)
                                        try {
                                            windowManager.updateViewLayout(overlayComposeView, params)
                                        } catch (ignored: Exception) {}
                                    }
                                }
                            )
                        }
                    }
                }
            }

            val layoutParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                x = 0
                y = targetY
            }

            try {
                windowManager.addView(view, layoutParams)
                overlayComposeView = view
                currentLayoutParams = layoutParams
                voiceCommandListener?.startListening()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            currentLayoutParams?.let { params ->
                if (params.y != targetY) {
                    params.y = targetY
                    try {
                        windowManager.updateViewLayout(overlayComposeView, params)
                    } catch (ignored: Exception) {}
                }
            }
        }
    }

    /**
     * Executes One-Tap Accept: Taps accept button in underlying ride-hailing app directly
     */
    private fun performOneTapAcceptGesture() {
        val rootNode = rootInActiveWindow
        if (rootNode != null) {
            val acceptKeywords = arrayOf("قبول", "Accept", "طلب", "Confirm")
            for (keyword in acceptKeywords) {
                val nodes = rootNode.findAccessibilityNodeInfosByText(keyword)
                if (!nodes.isNullOrEmpty()) {
                    for (node in nodes) {
                        if (node.isClickable) {
                            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                            removeOverlay()
                            return
                        } else if (node.parent?.isClickable == true) {
                            node.parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                            removeOverlay()
                            return
                        }
                    }
                }
            }
        }

        // Fallback: Dispatch tap gesture on standard accept position (bottom center)
        val displayMetrics = resources.displayMetrics
        val clickX = displayMetrics.widthPixels / 2f
        val clickY = displayMetrics.heightPixels * 0.88f

        val path = Path().apply {
            moveTo(clickX, clickY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()

        dispatchGesture(gesture, null, null)
        removeOverlay()
    }

    private fun openInGoogleMaps(destination: String) {
        val query = if (destination.isNotBlank()) destination else "Cairo, Egypt"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(query))).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            setPackage("com.google.android.apps.maps")
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            val genericIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(query))).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                startActivity(genericIntent)
            } catch (ignored: Exception) {}
        }
    }

    private fun removeOverlay() {
        voiceCommandListener?.stopListening()
        overlayComposeView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        overlayComposeView = null
        currentLayoutParams = null
        overlayLifecycleOwner?.onDestroy()
        overlayLifecycleOwner = null
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_RUNNING_LOW) {
            driverAiCore.clearVolatileCaches()
        }
    }

    override fun onInterrupt() {
        removeOverlay()
    }

    override fun onDestroy() {
        removeOverlay()
        voiceCommandListener?.stopListening()
        driverAiCore.release()
        serviceScope.cancel()
        taskChannel.close()
        super.onDestroy()
    }
}
