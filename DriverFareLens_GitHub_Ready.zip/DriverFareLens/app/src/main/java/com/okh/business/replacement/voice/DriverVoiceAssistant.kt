package com.okh.business.replacement.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.okh.business.replacement.core.model.TripMetrics
import java.util.Locale

class DriverVoiceAssistant(context: Context) : TextToSpeech.OnInitListener {

    private val applicationContext = context.applicationContext
    private var tts: TextToSpeech? = TextToSpeech(applicationContext, this)
    private val audioManager = applicationContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private var isReady = false
    var isEnabled: Boolean = true

    // Callback invoked when speech finishes, allowing microphone to listen without acoustic feedback
    var onSpeechDoneCallback: (() -> Unit)? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val arabicLocale = Locale("ar")
            val result = tts?.setLanguage(arabicLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.ENGLISH
            }
            tts?.setSpeechRate(1.15f)
            isReady = true

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}

                override fun onDone(utteranceId: String?) {
                    abandonAudioFocus()
                    onSpeechDoneCallback?.invoke()
                }

                override fun onError(utteranceId: String?) {
                    abandonAudioFocus()
                    onSpeechDoneCallback?.invoke()
                }
            })
        }
    }

    fun announceOffer(metrics: TripMetrics) {
        if (!isEnabled || !isReady || tts == null) {
            onSpeechDoneCallback?.invoke()
            return
        }

        requestAudioFocusDucking()

        val profitDescription = if (metrics.isProfitable) "عرض مربح جداً" else "ربح منخفض"
        val speechText = "${metrics.platform.displayName}. ${metrics.fare.toInt()} ${metrics.currency}. المسافة ${metrics.distanceKm} كيلو. $profitDescription"

        tts?.speak(speechText, TextToSpeech.QUEUE_FLUSH, null, "TRIP_OFFER_${System.currentTimeMillis()}")
    }

    private fun requestAudioFocusDucking() {
        if (audioManager == null) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .build()
            audioManager.requestAudioFocus(focusRequest)
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(null, AudioManager.STREAM_NOTIFICATION, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        }
    }

    private fun abandonAudioFocus() {
        if (audioManager == null) return
        @Suppress("DEPRECATION")
        audioManager.abandonAudioFocus(null)
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isReady = false
    }
}
