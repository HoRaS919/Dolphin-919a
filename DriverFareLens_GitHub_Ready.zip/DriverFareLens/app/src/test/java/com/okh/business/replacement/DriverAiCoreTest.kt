package com.okh.business.replacement

import com.okh.business.replacement.core.DriverAiCore
import com.okh.business.replacement.core.SmartRouteEngine
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class DriverAiCoreTest {

    private val testDispatcher = StandardTestDispatcher()

    @Test
    fun testParseOfferText_ValidUberOffer() = runTest(testDispatcher) {
        val aiCore = DriverAiCore(SmartRouteEngine(minAcceptableRatePerKm = 10.0), testDispatcher)

        aiCore.evaluateScreenOffer(
            rawText = "Trip offer 120.0 EGP distance 10.0 km time 20 min rating 4.9",
            packageName = "com.ubercab"
        )
        testDispatcher.scheduler.advanceUntilIdle()

        val metrics = aiCore.currentMetrics.value
        assertNotNull(metrics)
        assertEquals(120.0, metrics?.fare ?: 0.0, 0.01)
        assertEquals(10.0, metrics?.distanceKm ?: 0.0, 0.01)
        assertEquals(12.0, metrics?.ratePerKm ?: 0.0, 0.01)
        assertTrue(metrics?.isProfitable == true)
    }

    @Test
    fun testParseOfferText_UnprofitableOffer() = runTest(testDispatcher) {
        val aiCore = DriverAiCore(SmartRouteEngine(minAcceptableRatePerKm = 10.0), testDispatcher)

        aiCore.evaluateScreenOffer(
            rawText = "Offer 40.0 EGP distance 8.0 km time 15 min",
            packageName = "com.ubercab"
        )
        testDispatcher.scheduler.advanceUntilIdle()

        val metrics = aiCore.currentMetrics.value
        assertNotNull(metrics)
        assertEquals(5.0, metrics?.ratePerKm ?: 0.0, 0.01)
        assertFalse(metrics?.isProfitable == true)
    }
}
