package com.okh.business.replacement

import com.okh.business.replacement.core.parser.FastOfferParser
import org.junit.Assert.*
import org.junit.Test

class FastOfferParserTest {

    @Test
    fun testParseOffer_ArabicNumerals() {
        val text = "عرض رحلة ١٢٠ ج.م المسافة ٨٫٥ كم الوقت ١٥ دقيقة تقييم ٤٫٩"
        val card = FastOfferParser.parseOffer(text)

        assertNotNull(card)
        assertEquals(120.0, card?.fare ?: 0.0, 0.01)
        assertEquals(8.5, card?.distanceKm ?: 0.0, 0.01)
        assertEquals(15, card?.durationMinutes ?: 0)
        assertEquals(4.9, card?.rating ?: 0.0, 0.01)
    }

    @Test
    fun testParseOffer_WesternDigitsWithEGP() {
        val text = "Uber offer: 85.0 EGP distance: 6.2 km duration: 12 min"
        val card = FastOfferParser.parseOffer(text)

        assertNotNull(card)
        assertEquals(85.0, card?.fare ?: 0.0, 0.01)
        assertEquals(6.2, card?.distanceKm ?: 0.0, 0.01)
        assertEquals(12, card?.durationMinutes ?: 0)
    }
}
