# Driver Fare Lens (Apex Edition v8.0) 🚗💨

**Driver Fare Lens** is an ultra-fast, intelligent real-time overlay HUD designed for ride-hailing drivers in Egypt (Uber, DiDi, InDrive). It analyzes trip requests instantly using high-speed screen accessibility scanning and ML Kit OCR, computing net profit, hourly rate, spatial surge zones, fuel costs, and driver fatigue telemetry without storing sensitive customer PII.

---

## ⚡ Cloud Build with GitHub Actions (Recommended)
This repository includes a pre-configured GitHub Actions CI/CD workflow (`.github/workflows/build_apk.yml`).

1. Push or upload this repository to GitHub.
2. Go to the **Actions** tab.
3. Select **Build Driver Fare Lens APK** and run or wait for automated push trigger.
4. Download the generated APK directly from the **Artifacts** section at the bottom of the run!

---

## 🚀 Key Features
- **Instant Overlay HUD:** Floating card appearing automatically over Uber, DiDi, and InDrive offer cards.
- **Apex Architecture (v8.0):** Pure Kotlin, Jetpack Compose, Coroutines 1.8, Room Database 2.6, Material 3.
- **Smart Geo & Surge Radar:** Intelligent zone classification for Cairo & 6th of October zones.
- **Battery & Thermal Guard:** Automatically manages polling frequency based on device thermal status.
- **Bluetooth Auto-Trigger:** Automatically detects car Bluetooth connection to engage Drive Mode.
- **Voice Commands:** Offline audio assistant for hands-free acceptance and dismiss actions.
- **Strict Privacy Compliance:** Google Play Accessibility and Privacy compliant.

See `GITHUB_GUIDE.md` for complete build instructions.
