# Google Play Policy & Accessibility Compliance Checklist

- [x] **Prominent Disclosure**:
  - Implemented via `ProminentDisclosureDialog.kt` inside `MainActivity`.
  - Explains specifically *why* accessibility is needed, *what* is extracted (trip fare/distance), and confirms zero data collection.
- [x] **Zero Background Data Harvesting**:
  - No background network connections or analytics.
- [x] **Appropriate Use of Accessibility API**:
  - Used strictly for assistive driving calculations when the driver is actively receiving trip requests.
