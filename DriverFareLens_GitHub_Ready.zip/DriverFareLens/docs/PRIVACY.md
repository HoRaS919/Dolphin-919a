# Privacy Policy - Driver Fare Lens

Driver Fare Lens was built with strict privacy and security principles:

1. **100% On-Device Processing**:
   - The application inspects trip details directly on the driver device screen using Android Accessibility APIs.
   - Text parsing, metric calculation, and profit evaluations are conducted purely in memory and on-device.

2. **No Data Collection or Transmission**:
   - Driver Fare Lens does NOT collect, store, or transmit any personally identifiable information (PII), passenger names, contact numbers, or real-time location points.
   - No data is uploaded to remote servers or third-party analytical SDKs.

3. **No Account Tracking**:
   - The app operates autonomously without requiring account sign-ins or personal credentials.
