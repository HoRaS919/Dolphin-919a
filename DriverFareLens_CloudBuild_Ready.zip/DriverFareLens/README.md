# Driver Fare Lens (Modernized v2.0)

A modern, high-performance Android driving assistant for ride-hailing drivers (Uber, DiDi, inDrive).

## Key Features
- **Modern Android Architecture (MAD)**: Kotlin, Jetpack Compose, Material 3, StateFlow, and Coroutines.
- **Glassmorphic / High-Contrast Floating Overlay**: Legible at a glance during day and night driving.
- **Real-Time On-Device Metrics**: Instant net profit, rate per kilometer, and passenger rating evaluation.
- **Thermal & Battery Adaptive**: Throttles processing frequency based on device thermal headroom.
- **Google Play Compliant**: Adheres to Accessibility API Prominent Disclosure requirements with zero data leakage.

## Tech Stack
- **Language**: Kotlin 1.9+
- **UI Toolkit**: Jetpack Compose & Material 3
- **Async & Reactive**: Kotlin Coroutines & Flow
- **Compatibility**: Android 7.0+ (API 24 to 34)
